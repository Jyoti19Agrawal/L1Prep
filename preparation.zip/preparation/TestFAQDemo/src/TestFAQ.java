import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Map;
import java.util.TreeMap;

/*Ques 3-
 * class MyOwnException extends Exception{ }
class A
{	public void test(int i) throws MyOwnException
	{
	if (i==0) throw new MyOwnException();
	}
	}*/

 class A
{
public A()
{
	System.out.println("A");}
}

 class B extends A implements Serializable
{
public B() {
	System.out.println("B");
}	
}


public class TestFAQ  {
	
	


	public static void main(String[] args)  throws Exception
	{
		/* Ques 1-
		 * byte b; 
		 * int i = 0; 
		 * char ch=' '; 
		 * float f; 
		 * b=(byte)i; //we can not assign i to b because byte has size 1 so typecast 
		 * b=(short)10;// by default integer, to convert into byte typecast 
		 * long l=80L; //double cannot assign to float so do explicit typecasting 
		 * f=90.0F; with respect to typecasting, with respect to size you have to speak in datatype
		 */
		
		/*Ques 2
		try {
			return;
		} finally {
			System.out.println("Hello");
		}*/
		
		/*(Extension of Above)Ques 3-
		 * //method is throwing an exception, so we have to handle it otherwise compilation error
		//either throws Or Handle by try catch
		try {
			new A().test(0);
		} catch (MyOwnException e) {
			e.printStackTrace();
		}*/
		
		
		 
		/* Ques-4
		 * Thread a=new Thread(new TestFAQ());
		a.start(); //in a ready state
		System.out.println("Begin");
		a.join();//you can control, how it should execute
		System.out.println("End");
	}
	public void run()
	{
		System.out.println("Run");
	}
	
	//start does not means that it internally call run, it means that it enter in a ready state.
	// we have to notify always for wait. wait is different in java.
*/
		
		/*Ques-5
		 * 
		 * String i = " ";
		Map mymap= new TreeMap();
		for(int x=0; x<3; x++)
		{
			i +=x;
			String j="K";
			mymap.put(i, j);
			j+= "D";
			mymap.put(i,j);
			System.out.println(" "+i+j);
		}
		 System.out.println(mymap.size());*/
		
		B b=new B();
		ObjectOutputStream save =new ObjectOutputStream(new FileOutputStream("datafile"));
		save.writeObject(b);
		save.flush();
		ObjectInputStream restore = new ObjectInputStream(new FileInputStream("datafile"));
		System.out.println("*****************");
		B z= (B)restore.readObject();
		System.out.println(z);// it will print address
		
/*hmari file m function write ni hota hai to abhi datafile m srf object 'save' hai qki hmare pss abhi instance variable nahi hai.
		At the time of deserialization, jvm will implicitly call constructor.
*/		
		
		/*serializtaion is the process of converting object in the format so that it can go in serialize way
		 * 
		 * hum line 105 m B ka Object bnaye hai or Class b 
		serializable ko implement kr rha h to jo class serializable
		ko implement kr rha h wo uske parent k constructor ko hi 
		call krta hai
		output = A  B  A
		*/

	}
	
}
